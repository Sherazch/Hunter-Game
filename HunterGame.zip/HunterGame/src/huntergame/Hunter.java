/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package huntergame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
/**
 *
 * @author Umer
 */
public class Hunter extends JFrame implements Runnable{
    JPanel panel = new JPanel();
    JLabel label = new JLabel();
    JLabel l=new JLabel();
    JLabel l1 = new JLabel();
    JLabel l2 = new JLabel();
    JLabel l3 = new JLabel();
    JLabel l4 = new JLabel();
    
    int score = 0;
    
    
    ImageIcon im=new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\hunter.png");
    ImageIcon im1=new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\game.jpg");
    ImageIcon im2 = new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\bullet.png");
    ImageIcon im3 = new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\anim.gif");
    ImageIcon im4 = new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\over.jpg");
    
    int labelY;
    int bulletX = 108;
    int bulletY = 341;
    int anim1;
    int anim2;
    int animX;
    int anim;        
    
    int key1=0;
    int state = 1;
    
    Thread t;
    Hunter(){                           //Constructor Initialization
        anim_intializer();              //Function Calling
        
        /* Frame Attributes from Line 61 to 67*/
        
        setSize(961, 694);              
        setResizable(true);
        setTitle("Hunter");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
    
        t = new Thread(this);       //thread initialization
        t.start();                  //thread start
        
        //Hunter Attribs        
        l.setIcon(im);
        labelY=314;
        l.setBounds(15, labelY, im.getIconWidth(),im.getIconHeight());
        
        //Background Feild Attribs
        label.setIcon(im1);
        label.setBounds(0,0,im1.getIconWidth(),im1.getIconHeight());        ;
        
        //Bullet Attribs
        l1.setIcon(im2);
        l1.setBounds(bulletX,bulletY,im2.getIconWidth(),im2.getIconHeight());
        l1.setVisible(false);
        
        //Animal Attribs
        l2.setIcon(im3);
        l2.setBounds(animX,anim,im3.getIconWidth(),im3.getIconHeight());
        
        
        //Game Over cover attribs
        l3.setIcon(im4);
        l3.setBounds(0,0,im4.getIconWidth(),im4.getIconHeight());
        l3.setVisible(false);
        
        
        //Score Feild Attribs
        l4.setVisible(false);
        l4.setText(""+score);
        l4.setBounds(300, 220, 100, 50);
        l4.setBackground(Color.white);
        l4.setFont(new Font("Arial", Font.BOLD, 60));
        
        //Adding all labels into panel
        panel.add(l4);
        panel.add(l3);
        panel.add(l2);
        panel.add(l1);
        panel.add(l);
        panel.add(label);
        panel.setLayout(null);
        add(panel);             //adding panel into frame
        
        //Mouse Listner on Background Feild
        l.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent me) {
            }

            @Override
            public void mousePressed(MouseEvent me) {
                int x = me.getX();
                int y = me.getY();
                
                if((x>11&&x<69)&&(y>26&&y<69)){         //Logic for Back Button
                    dispose();
                    new menu();
                }
            }

            @Override
            public void mouseReleased(MouseEvent me) {
            }

            @Override
            public void mouseEntered(MouseEvent me) {
            }

            @Override
            public void mouseExited(MouseEvent me) {
            }
        });
        //Mouse Listner After Game over
        l3.addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent me) {
            }

            @Override
            public void mousePressed(MouseEvent me) {  
                int x = me.getX();
                int y = me.getY();
                
                if((x>42&&x<305)&&(y>540&&y<597)){      //Going Back to Main Menu Logic
                    dispose();
                    new menu();
                    
                }
                
                if((x>323&&x<587)&&(y>540&&y<597)){     //Game Exit Logic
                    System.exit(0);
                    
                }
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
            }

            @Override
            public void mouseEntered(MouseEvent me) {
            }

            @Override
            public void mouseExited(MouseEvent me) {
            }
        });
        //Adding Key Listners for gaming control
        addKeyListener(new KeyListener() {

            @Override
            public void keyTyped(KeyEvent ke) {
                int key = ke.getKeyCode();
                
            }

            @Override
            public void keyPressed(KeyEvent ke) {          //Hunter Move up logic
                int key = ke.getKeyCode();
                if(key==KeyEvent.VK_UP){
                    labelY -=10;
                    l.setLocation(15,labelY);
                    bulletY -=10;
                    l1.setLocation(bulletX, bulletY);
                    repaint();
                    
                }
                if(key==KeyEvent.VK_DOWN){      //HUnter Move down logic
                    labelY +=10;
                    l.setLocation(15,labelY);
                    bulletY +=10;
                    l1.setLocation(bulletX, bulletY);
                    repaint();
                }
                if(key == KeyEvent.VK_SPACE){       //Bullet Visibility Logic
                    l1.setVisible(true);
                    key1=1;                         
                }                               
            }

            @Override
            public void keyReleased(KeyEvent ke) {
            }
        });
       
       revalidate();
       repaint();
    }

    @Override
    public void run() {             //Java threading implementation
        while(bulletX!=725 || animX!=150){
            if(state==1){       //Check state of animal
                animX -=5;
            }
            else{
                animX = animX;
            }
            l2.setLocation(animX, anim);        //Logic for animal moving
            if(animX<150){                      //Logic for game over
                l2.setLocation(150, anim);      //check for location
                label.setVisible(false);        //set visibility of label from line 235 to 241
                l.setVisible(false);        
                l1.setVisible(false);
                l2.setVisible(false);
                l3.setVisible(true);  
                l4.setText(""+score);
                l4.setVisible(true);
                
            }
            if(key1==1){        //Logic for both bullet and animal collision
                l1.setLocation(bulletX+=5, bulletY);    //Set Location according to motion
                bulletX+=5;
                if(bulletX+30>animX && bulletY< anim+l2.getHeight() && bulletY>anim-45 && bulletY<anim-20){ //collision Occur
                    l4.setVisible(false);
                    state=2;
                
                anim_intializer();
                score +=10;     //set score
            }
            }
            
            if(bulletX>725){        // bullet motion logic
                bulletX=108;
                l1.setLocation(bulletX,bulletY);
                l1.setVisible(true);
                l1.setLocation(bulletX+=5, bulletY);
                bulletX+=5;
            }
                       
            
        try {
            
            Thread.sleep(25);   //thread sleep time 25= 25 milli sec
            
        } catch (Exception e) {
        }
        repaint();
        }
        
    }
    int random(){   //Function for random animal generator
        Random random = new Random();
        int anim3 = (int)(Math.random()*anim2);
        int anim = ((anim3>anim1)?anim3:anim1+anim3);
        l2.setVisible(true);
        
        return anim;
    }
    void anim_intializer(){     //Animal initializer to reGenerate animal again and again.
        anim1 = 120;
        anim2 = 550;
        animX = 880;
        anim = random();
        state=1;
        
    }
    }
    
