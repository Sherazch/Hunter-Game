
package huntergame;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class menu extends JFrame{
    menu(){
        setSize(961, 694);
        setResizable(false);
        setTitle("Hunter Menu");
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
        this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);
        
        add(new JLabel(new ImageIcon("F:\\workspace\\HunterGame\\src\\huntergame\\menu.jpg")));
        
        addMouseListener(new MouseListener() {

            @Override
            public void mouseClicked(MouseEvent me) {
            }

            @Override
            public void mousePressed(MouseEvent me) {
                int x = me.getX();
		int y = me.getY();
                
                if((x>383&&x<586)&&(y>300&&y<360)){
                    dispose();
                    new Hunter();
                }
                
                if((x>383&&x<586)&&(y>383&&y<443)){
                    dispose();
                    new Help();
                }
                
                if((x>383&&x<586)&&(y>463&&y<523)){
                    System.exit(0);
                    
                }
            }
            @Override
            public void mouseReleased(MouseEvent me) {
            }

            @Override
            public void mouseEntered(MouseEvent me) {
            }

            @Override
            public void mouseExited(MouseEvent me) {
            }
        });
        revalidate();
    }   
}
